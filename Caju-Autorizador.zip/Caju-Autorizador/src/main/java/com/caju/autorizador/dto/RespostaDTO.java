package com.caju.autorizador.dto;

import lombok.*;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RespostaDTO implements Serializable {
    private String code;
}
