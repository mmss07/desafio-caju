package com.caju.autorizador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CajuAutorizadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CajuAutorizadorApplication.class, args);
	}

}
