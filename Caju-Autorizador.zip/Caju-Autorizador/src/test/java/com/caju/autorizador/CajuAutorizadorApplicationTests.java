package com.caju.autorizador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CajuAutorizadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
